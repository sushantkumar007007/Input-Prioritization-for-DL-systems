# Add comment abour the resourse

from tensorflow.keras.layers import Input, Conv2D, MaxPooling2D, UpSampling2D, BatchNormalization, Activation, Flatten, Dense, Conv2DTranspose, Reshape
from tensorflow.keras.models import Model


def model_01():
    input_img = Input(shape=(32,32,3))
    
    x = Conv2D(16, (3,3), activation='relu', padding="same")(input_img)
    x = Conv2D(16, (3,3), activation='relu', padding="same")(x)
    x = MaxPooling2D(pool_size=(2,2), padding="same")(x)
    x = Conv2D(32, (3,3), activation='relu', padding="same")(x)
    x = Conv2D(32, (3,3), activation='relu', padding="same")(x)
    x = MaxPooling2D(pool_size=(2,2))(x)
    x = Conv2D(64, (3,3), activation='relu', padding="same")(x)
    x = Conv2D(64, (3,3), activation='relu', padding="same")(x)
    encoded = MaxPooling2D(pool_size=(2,2))(x)
    
    x = Conv2D(64, (3,3), activation='relu', padding='same')(encoded)
    x = Conv2D(64, (3,3), activation='relu', padding="same")(x)
    x = UpSampling2D((2,2))(x)
    x = Conv2D(32, (3,3), activation='relu', padding='same')(x)
    x = Conv2D(32, (3,3), activation='relu', padding="same")(x)
    x = UpSampling2D((2,2))(x)
    x = Conv2D(16, (3,3), activation='relu', padding='same')(x)
    x = Conv2D(16, (3,3), activation='relu', padding="same")(x)
    x = UpSampling2D((2,2))(x)
    decoded = Conv2D(3, (3,3), activation='sigmoid', padding='same')(x)
    
    model = Model(input_img, decoded)
    return model


def model_02():
    input_img = Input(shape=(32,32,3))
    
    x = Conv2D(32, (3,3), activation='relu', padding="same")(input_img)
    x = MaxPooling2D(pool_size=(2,2), padding="same")(x)
    x = Conv2D(16, (3,3), activation='relu', padding="same")(x)
    x = MaxPooling2D(pool_size=(2,2))(x)
    x = Conv2D(8, (3,3), activation='relu', padding="same")(x)
    encoded = MaxPooling2D(pool_size=(2,2))(x)
    
    x = Conv2D(8, (3,3), activation='relu', padding='same')(encoded)
    x = UpSampling2D((2,2))(x)
    x = Conv2D(16, (3,3), activation='relu', padding='same')(x)
    x = UpSampling2D((2,2))(x)
    x = Conv2D(32, (3,3), activation='relu', padding='same')(x)
    x = UpSampling2D((2,2))(x)
    decoded = Conv2D(3, (3,3), activation='sigmoid', padding='same')(x)
    
    model = Model(input_img, decoded)
    return model

def model_03():
    input_img = Input(shape=(32,32,3))
    x = Conv2D(64, (3, 3), padding='same')(input_img)
    x = BatchNormalization()(x)
    x = Activation('relu')(x)
    x = MaxPooling2D((2, 2), padding='same')(x)
    x = Conv2D(32, (3, 3), padding='same')(x)
    x = BatchNormalization()(x)
    x = Activation('relu')(x)
    x = MaxPooling2D((2, 2), padding='same')(x)
    x = Conv2D(16, (3, 3), padding='same')(x)
    x = BatchNormalization()(x)
    x = Activation('relu')(x)
    encoded = MaxPooling2D((2, 2), padding='same')(x)

    x = Conv2D(16, (3, 3), padding='same')(encoded)
    x = BatchNormalization()(x)
    x = Activation('relu')(x)
    x = UpSampling2D((2, 2))(x)
    x = Conv2D(32, (3, 3), padding='same')(x)
    x = BatchNormalization()(x)
    x = Activation('relu')(x)
    x = UpSampling2D((2, 2))(x)
    x = Conv2D(64, (3, 3), padding='same')(x)
    x = BatchNormalization()(x)
    x = Activation('relu')(x)
    x = UpSampling2D((2, 2))(x)
    x = Conv2D(3, (3, 3), padding='same')(x)
    x = BatchNormalization()(x)
    decoded = Activation('sigmoid')(x)
    
    model = Model(input_img, decoded)
    return model

def model_04():
    input_img = Input(shape=(32,32,3))
    x = Conv2D(64, 4, strides=2, activation='relu', padding='same')(input_img)
    x = Conv2D(128, 4, strides=2, activation='relu', padding='same')(x)
    x = Conv2D(512, 4, strides=2, activation='relu', padding='same')(x)
    x = Flatten()(x)
    x = Dense(1024)(x)
    x = Dense(4*4*128)(x)
    x = Reshape(target_shape=(4, 4, 128))(x)
    x = Conv2DTranspose(256, 4, strides=2, padding='same', activation='relu')(x)
    x = Conv2DTranspose(64, 4, strides=2, padding='same', activation='relu')(x)
    decoded = Conv2DTranspose(3, 4, strides=2, padding='same', activation='sigmoid')(x)
    model = Model(input_img, decoded)
    return model
