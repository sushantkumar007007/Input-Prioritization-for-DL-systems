import os

import tensorflow as tf

from tensorflow.keras.utils import to_categorical
from tensorflow.keras.models import Model, Sequential, load_model
from tensorflow.keras.layers import Input, Conv2D, MaxPooling2D, Conv2DTranspose, Flatten, Dense, UpSampling2D, Dropout, Add, Activation, BatchNormalization

from surprise_adequacy import SurpriseAdequacyConfig, DSA, LSA


CLIP_MIN = -0.5
CLIP_MAX = 0.5

print(tf.config.experimental.list_physical_devices('GPU'))

(x_train, y_train), (x_test, y_test) = tf.keras.datasets.mnist.load_data(path=os.path.expanduser('~/dev/data/mnist/mnist.npz'))

x_train = x_train.reshape(-1, 28, 28, 1)
x_test = x_test.reshape(-1, 28, 28, 1)

x_train = x_train.astype("float32")
x_test = x_test.astype("float32")
x_train = (x_train / 255.0) - (1.0 - CLIP_MAX)
x_test = (x_test / 255.0) - (1.0 - CLIP_MAX)

y_train = to_categorical(y_train, 10)
y_test = to_categorical(y_test, 10)

model = load_model('./kim_cnn.h5')

config = SurpriseAdequacyConfig(saved_path='./tmp', is_classification=True, num_classes=10, 
                                layer_names=["activation_8"], ds_name="mnist")

sa = DSA(model=model, train_data=x_train, config=config)

sa.prep(use_cache=False)

suprises, predictions = sa.calc(target_data=x_test, use_cache=False, ds_type='test')
