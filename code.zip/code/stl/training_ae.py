import json

from tensorflow.keras.layers import (
    Input, Conv2D, MaxPooling2D, UpSampling2D, BatchNormalization, Activation, Flatten, Dense, Conv2DTranspose, Reshape,
)
from tensorflow.keras.models import Model

import tensorflow_datasets as tfds


(x_train, _) = tfds.as_numpy(tfds.load('stl10', split='train', batch_size=-1, as_supervised=True))
(x_test, _) = tfds.as_numpy(tfds.load('stl10', split='test', batch_size=-1, as_supervised=True))

x_train = x_train.astype('float32') / 255.
x_test = x_test.astype('float32') / 255.

# define AE model
input_img = Input(shape=(96,96,3))
x = Conv2D(64, (3, 3), padding='same')(input_img)
x = BatchNormalization()(x)
x = Activation('relu')(x)
x = MaxPooling2D((2, 2), padding='same')(x)
x = Conv2D(32, (3, 3), padding='same')(x)
x = BatchNormalization()(x)
x = Activation('relu')(x)
x = MaxPooling2D((2, 2), padding='same')(x)
x = Conv2D(16, (3, 3), padding='same')(x)
x = BatchNormalization()(x)
x = Activation('relu')(x)
encoded = MaxPooling2D((2, 2), padding='same')(x)

x = Conv2D(16, (3, 3), padding='same')(encoded)
x = BatchNormalization()(x)
x = Activation('relu')(x)
x = UpSampling2D((2, 2))(x)
x = Conv2D(32, (3, 3), padding='same')(x)
x = BatchNormalization()(x)
x = Activation('relu')(x)
x = UpSampling2D((2, 2))(x)
x = Conv2D(64, (3, 3), padding='same')(x)
x = BatchNormalization()(x)
x = Activation('relu')(x)
x = UpSampling2D((2, 2))(x)
x = Conv2D(3, (3, 3), padding='same')(x)
x = BatchNormalization()(x)
decoded = Activation('sigmoid')(x)
    
autoencoder = Model(input_img, decoded)
autoencoder.summary()

# compile, fit, and save
autoencoder.compile(optimizer='adam', loss='binary_crossentropy')
history = autoencoder.fit(x_train, x_train, epochs=2, batch_size=128, shuffle=True, validation_data=(x_test, x_test))
autoencoder.save('./tmp/autoencoder.h5')

with open('./tmp/training_history.json', 'w') as f:
    json.dump(history.history, f)
    
print("Training complete!")
