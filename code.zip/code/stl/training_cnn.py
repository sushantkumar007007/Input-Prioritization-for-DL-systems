import json

import tensorflow_datasets as tfds

from tensorflow.keras.utils import to_categorical
from tensorflow.keras.layers import Flatten, Dense, Conv2D, MaxPooling2D, Dropout
from tensorflow.keras.models import Sequential
from tensorflow.keras.optimizers import Adam, SGD
from tensorflow.keras.applications.vgg16 import VGG16
from tensorflow.keras.applications.resnet import ResNet50


# load the data
(x_train, y_train) = tfds.as_numpy(tfds.load('stl10', split='train', batch_size=-1, as_supervised=True))
(x_test, y_test) = tfds.as_numpy(tfds.load('stl10', split='test', batch_size=-1, as_supervised=True))

x_train = x_train.astype('float32')
x_test = x_test.astype('float32')

x_train = x_train / 255.0
x_test = x_test / 255.0

y_train = to_categorical(y_train, 10)
y_test = to_categorical(y_test, 10)


# define CNN model
model = Sequential()

model.add(Conv2D(32, (3,3), activation='relu', padding='same', input_shape=(96,96,3)))
model.add(Conv2D(32, (3,3), activation='relu', padding='same'))
model.add(MaxPooling2D(pool_size=(2,2)))
model.add(Dropout(0.2))
model.add(Conv2D(64, (3,3), activation='relu', padding='same'))
model.add(Conv2D(64, (3,3), activation='relu', padding='same'))
model.add(MaxPooling2D(pool_size=(2,2)))
model.add(Dropout(0.3))
model.add(Conv2D(128, (3,3), activation='relu', padding='same'))
model.add(Conv2D(128, (3,3), activation='relu', padding='same'))
model.add(MaxPooling2D(pool_size=(2,2)))
model.add(Dropout(0.4))
model.add(Flatten())
model.add(Dense(128, activation='relu'))
model.add(Dropout(0.5))
model.add(Dense(10, activation='softmax'))

model.summary()

# compile, fit, and save
model.compile(loss='categorical_crossentropy', optimizer=SGD(0.001, momentum=0.9), metrics=['accuracy'])
history = model.fit(x_train, y_train, epochs=1000, batch_size=128, shuffle=True, validation_data=(x_test, y_test))
model.save("./tmp/model.h5")

with open('./tmp/training_history.json', 'w') as f:
    json.dump(history.history, f)
    
print("Training complete!")
