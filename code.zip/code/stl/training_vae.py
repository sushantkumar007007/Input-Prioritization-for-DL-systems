import os
import json
import numpy as np

from tensorflow import keras
from tensorflow.keras import layers

import tensorflow_datasets as tfds

from vae import Sampling, VAE


(x_train, _) = tfds.as_numpy(tfds.load('stl10', split='train', batch_size=-1, as_supervised=True))
(x_test, _) = tfds.as_numpy(tfds.load('stl10', split='test', batch_size=-1, as_supervised=True))

x_train = x_train.astype('float32') / 255.
x_test = x_test.astype('float32') / 255.

latent_dim = 2 # 256

encoder_inputs = keras.Input(shape=(96, 96, 3))
x = layers.Conv2D(128, 3, activation="relu", strides=2, padding="same")(encoder_inputs) # 32
x = layers.Conv2D(64, 3, activation="relu", strides=2, padding="same")(x) # 64
x = layers.Conv2D(32, 3, activation="relu", strides=2, padding="same")(x) # 128
x = layers.Flatten()(x)
z_mean = layers.Dense(latent_dim, name="z_mean")(x)
z_log_var = layers.Dense(latent_dim, name="z_log_var")(x)
z = Sampling()([z_mean, z_log_var])
encoder = keras.Model(encoder_inputs, [z_mean, z_log_var, z], name="encoder")
encoder.summary()

latent_inputs = keras.Input(shape=(latent_dim,))
x = layers.Dense(12 * 12 * 32, activation="relu")(latent_inputs) # 128
x = layers.Reshape((12, 12, 32))(x) # 128
x = layers.Conv2DTranspose(32, 3, activation="relu", strides=2, padding="same")(x) # 128
x = layers.Conv2DTranspose(64, 3, activation="relu", strides=2, padding="same")(x) # 64
x = layers.Conv2DTranspose(128, 3, activation="relu", strides=2, padding="same")(x) # 32
decoder_outputs = layers.Conv2DTranspose(3, 3, activation="sigmoid", padding="same")(x)
decoder = keras.Model(latent_inputs, decoder_outputs, name="decoder")
decoder.summary()

vae = VAE(encoder, decoder)

vae.compile(optimizer='adam')

history = vae.fit(x_train, epochs=2, batch_size=128)

vae.save_weights('./tmp/vae_weights', save_format='tf')

with open('./tmp/training_history.json', 'w') as f:
    json.dump(history.history, f)
    
print("Training complete!")
