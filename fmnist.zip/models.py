# Add comment abour the resourse

from tensorflow.keras.layers import Input, Conv2D, MaxPooling2D, UpSampling2D
from tensorflow.keras.models import Model


def model_01():
    input_img = Input(shape=(28, 28, 1))

    x = Conv2D(16, (3, 3), activation='relu', padding='same')(input_img)
    x = MaxPooling2D((2, 2), padding='same')(x)
    x = Conv2D(8, (3, 3), activation='relu', padding='same')(x)
    x = MaxPooling2D((2, 2), padding='same')(x)
    x = Conv2D(8, (3, 3), activation='relu', padding='same')(x)
    encoded = MaxPooling2D((2, 2), padding='same')(x)

    # at this point the representation is (4, 4, 8) i.e. 128-dimensional

    x = Conv2D(8, (3, 3), activation='relu', padding='same')(encoded)
    x = UpSampling2D((2, 2))(x)
    x = Conv2D(8, (3, 3), activation='relu', padding='same')(x)
    x = UpSampling2D((2, 2))(x)
    x = Conv2D(16, (3, 3), activation='relu')(x)
    x = UpSampling2D((2, 2))(x)
    decoded = Conv2D(1, (3, 3), activation='sigmoid', padding='same')(x)

    autoencoder = Model(input_img, decoded)
    return autoencoder
    
def model_02(image_size, n_channels=3):
    x_input = Input(shape=(*image_size,n_channels))

    x_1 = Conv2D(64, 3, activation='relu', padding='same')(x_input)
    x_2 = MaxPooling2D((2,2), padding='same')(x_1)               

    x_3 = Conv2D(32, 3, activation='relu', padding='same')(x_2)
    x_4 = MaxPooling2D((2,2), padding='same')(x_3)              

    x_5 = Conv2D(16, 3, activation='relu', padding='same')(x_4)
    x_6 = MaxPooling2D((2,2), padding='same')(x_5)

    ############===============================================##############

    x = Conv2DTranspose(16, 3, activation='relu', padding='same')(x_6)
    x = UpSampling2D((2,2))(x)
    x = Add()([x,x_5])

    x = Conv2DTranspose(32, 3, activation='relu', padding='same')(x)
    x = UpSampling2D((2,2))(x)
    x = Add()([x,x_3])

    x = Conv2DTranspose(64, 3, activation='relu', padding='same')(x)
    x = UpSampling2D((2,2))(x)
    x = Add()([x,x_1])

    output = Conv2D(n_channels, 1, padding='same', activation='sigmoid')(x)

    autoencoder = Model(x_input, output)
    return autoencoder

def model_03():
    input_img = Input(shape=(28, 28, 1))

    x = Conv2D(32, (3, 3), activation='relu', padding='same')(input_img)
    x = MaxPooling2D((2, 2), padding='same')(x)
    x = Conv2D(32, (3, 3), activation='relu', padding='same')(x)
    encoded = MaxPooling2D((2, 2), padding='same')(x)

    # At this point the representation is (7, 7, 32)

    x = Conv2D(32, (3, 3), activation='relu', padding='same')(encoded)
    x = UpSampling2D((2, 2))(x)
    x = Conv2D(32, (3, 3), activation='relu', padding='same')(x)
    x = UpSampling2D((2, 2))(x)
    decoded = Conv2D(1, (3, 3), activation='sigmoid', padding='same')(x)

    autoencoder = Model(input_img, decoded)
    return autoencoder
