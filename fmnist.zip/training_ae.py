import os
import json

import numpy as np

from models import model_01, model_03

from tensorflow.keras.datasets.fashion_mnist import load_data
from tensorflow.keras.callbacks import TensorBoard, ModelCheckpoint


(x_train, _), (x_test, _) = load_data()

x_train = x_train.astype('float32') / 255.
x_test = x_test.astype('float32') / 255.

x_train = x_train.reshape(-1, 28, 28, 1)
x_test = x_test.reshape(-1, 28, 28, 1)

autoencoder = model_01()
autoencoder.summary()

autoencoder.compile(optimizer='adam', loss='binary_crossentropy')

tb_callback = TensorBoard(log_dir='./tmp', profile_batch=0)
cp_callback = ModelCheckpoint('./tmp/checkpoint.h5', save_best_only=True)

history = autoencoder.fit(x_train, x_train, epochs=2, batch_size=128, shuffle=True,
                          validation_data=(x_test, x_test), callbacks=[tb_callback,cp_callback])

autoencoder.save('./tmp/autoencoder.h5')

with open('./tmp/training_history.json', 'w') as f:
    json.dump(history.history, f)
    
print("Training complete!")
