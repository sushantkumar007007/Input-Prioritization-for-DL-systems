import os
import numpy as np

from tqdm import tqdm

from image_similarity_measures.quality_metrics import rmse

import tensorflow_datasets as tfds


(x_test, _) = tfds.as_numpy(tfds.load('stl10', split='test', batch_size=-1, as_supervised=True))

x_test = x_test.astype('float32') / 255.

prioritizations = []

for i in tqdm(range(len(x_test))):
    prioritizations.append(np.argsort([rmse(x_test[i], x_test[j]) for j in range(len(x_test))]))
    
np.save('./tmp/sim_prioritizations.npy', prioritizations)
